import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Swal from 'sweetalert2';
import { IoIosShareAlt } from 'react-icons/io';
import { useNavigate } from 'react-router-dom';
import './ViewReciveProfile.css'; 

export const ViewReciveProfile = () => {
    const templates = [
        { img1: "./Images/21.png", img2: "./Images/21.png", textcolor: "black" },
        { img1: "./Images/15.png", img2: "./Images/15.png", textcolor: "black" },
        { img1: "./Images/1.png", img2: "./Images/1.png", textcolor: "white" },
        { img1: "./Images/2.png", img2: "./Images/3.png", textcolor: "black" },
        { img1: "./Images/4.png", img2: "./Images/5.png", textcolor: "black" },
        { img1: "./Images/6.png", img2: "./Images/21.png", textcolor: "black" },
        { img1: "./Images/7.png", img2: "./Images/21.png", textcolor: "black" },
        { img1: "./Images/8.png", img2: "./Images/21.png", textcolor: "black" },
        { img1: "./Images/9.png", img2: "./Images/15.png", textcolor: "black" },
        { img1: "./Images/10.png", img2: "./Images/22.png", textcolor: "black" },
        { img1: "./Images/11.png", img2: "./Images/20.png", textcolor: "black" },
        { img1: "./Images/12.png", img2: "./Images/12.png", textcolor: "white" },
        { img1: "./Images/13.png", img2: "./Images/13.png", textcolor: "white" },
        { img1: "./Images/14.png", img2: "./Images/15.png", textcolor: "black" },
        { img1: "./Images/16.png", img2: "./Images/17.png", textcolor: "black" },
        { img1: "./Images/18.png", img2: "./Images/18.png", textcolor: "white" },
        { img1: "./Images/19.png", img2: "./Images/19.png", textcolor: "white" }
    ];

    const navigate = useNavigate();
    const [profileData, setProfileData] = useState([]);
    const [professionalProfileCard, setProfessionalProfileCard] = useState(templates[0]); // Default template
    const [selectedProfile, setSelectedProfile] = useState(null); // State for selected profile
    const receiverUserId = localStorage.getItem("userId");

    useEffect(() => {
        axios.get(`http://localhost:3000/share/getSharesWithProfile/${receiverUserId}`)
            .then(response => {
                setProfileData(response.data);
            })
            .catch(error => {
                console.error('Error fetching profile data:', error);
                Swal.fire('Error', 'Failed to fetch profiles', 'error');
            });
    }, [receiverUserId]);

    const handleProfileClick = (profile) => {
        setSelectedProfile(profile);
    };

    const handleBackClick = () => {
        setSelectedProfile(null);
    };

    return (
        <div className="container mt-5">
            <h2 className="text-center mb-4">Received Profiles</h2>
            {selectedProfile ? (
                <div className="profile-details border border-dark d-flex flex-column align-items-center">
                    <button className="btn btn-secondary  mb-3" onClick={handleBackClick}>Back</button>
                    <div className="card text-center h-100" style={{width:"18rem", color: professionalProfileCard.textcolor, background: `url(${professionalProfileCard.img1}) center/cover no-repeat`, backgroundSize: 'cover' }}>
                        <div className="card-body">
                            <img src="https://bootdey.com/img/Content/avatar/avatar7.png" className="card-img-top rounded-circle bg-light border border-3 border-secondary p-1 mx-auto" height="120px" style={{width:"120px"}} alt="Profile" />
                            <h5 className="card-title text-secondary fs-6 mt-3">{selectedProfile.profile.designation}</h5>
                            <p className="card-text fs-3 fw-bold">{selectedProfile.profile.fullName}</p>
                            <p className="card-text text-secondary">
                                <IoIosShareAlt className="me-1" />
                                {selectedProfile.profile.mobile} 
                            </p>
                            <p className="card-text text-secondary">
                                <IoIosShareAlt className="me-1" />
                                {selectedProfile.profile.email}
                            </p>
                            <p className="card-text text-secondary">
                                <IoIosShareAlt className="me-1" />
                                {selectedProfile.profile.address}
                            </p>
                            <p className="card-text text-secondary">
                                <IoIosShareAlt className="me-1" />
                                {selectedProfile.profile.organization}
                            </p>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="row row-cols-1 row-cols-md-3 g-4">
                    {profileData && profileData.length > 0 ? (
                        profileData.map((profile, index) => (
                            <div key={index} className="col" onClick={() => handleProfileClick(profile)}>
                                <div className='d-flex flex-wrap justify-content-evenly gap-4'>
                                    <div className="card personalcard1-img d-flex align-items-center justify-content-center flex-column text-center" style={{ width: "18rem", height: "500px", color: professionalProfileCard.textcolor, background: `url(${professionalProfileCard.img1}) center/cover no-repeat` }}>
                                        <div className="card-body p-4 pt-5 mt-3 p-0 m-0">
                                            <img src="https://bootdey.com/img/Content/avatar/avatar7.png" className="m-0 rounded-circle bg-light border border-3 border-secondary p-1 bg-light" width="120px" height="120px" alt="..." />
                                            <h5 className="card-title text-secondary fs-6 m-0 p-0">{profile.profile.designation}</h5>
                                            <p className="card-text fs-3 p-0 mb-3">{profile.profile.fullName}</p>
                                            <p className="card-text text-secondary text-start p-0 m-0 my-2">
                                                <IoIosShareAlt className="me-1" />
                                                {profile.profile.mobile}
                                            </p>
                                            <p className="card-text text-secondary text-start p-0 m-0 my-2">
                                                <IoIosShareAlt className="me-1" />
                                                {profile.profile.email}
                                            </p>
                                            <p className="card-text text-secondary text-start p-0 m-0 my-2">
                                                <IoIosShareAlt className="me-1" />
                                                {profile.profile.address}
                                            </p>
                                            <p className="card-text text-secondary text-start p-0 m-0 my-2">
                                                <IoIosShareAlt className="me-1" />
                                                {profile.profile.organization}
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))
                    ) : (
                        <p className="text-center">No profiles found</p>
                    )}
                </div>
            )}
            <div className="template-selection mt-5">
                <h5 className="text-center">Select Profile Template</h5>
                <div className="d-flex justify-content-center flex-wrap">
                    {templates.map((img, index) => (
                        <div key={index} className={`template-card ${img === professionalProfileCard ? 'border-primary' : ''}`} onClick={() => setProfessionalProfileCard(img)}>
                            <img src={img.img1} alt="Template" className="img-thumbnail m-2" />
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};
