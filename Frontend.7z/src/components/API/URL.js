export const API ={
    signUp:"http://localhost:3000/user/signup",
    signIn : "http://localhost:3000/user/signin"
}